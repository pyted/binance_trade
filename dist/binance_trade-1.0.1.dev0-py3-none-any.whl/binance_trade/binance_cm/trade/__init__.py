from binance_trade.binance_cm.trade.open import TradeOpen
from binance_trade.binance_cm.trade.close import TradeClose


class TradeCM(TradeOpen, TradeClose):
    pass
