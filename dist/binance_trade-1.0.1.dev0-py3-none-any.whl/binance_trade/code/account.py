ASSET_ERROR = ['ASSET_ERROR', '找不到Asset']
