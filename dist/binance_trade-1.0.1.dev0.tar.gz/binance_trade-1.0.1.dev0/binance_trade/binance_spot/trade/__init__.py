from binance_trade.binance_spot.trade.open import TradeOpen
from binance_trade.binance_spot.trade.close import TradeClose


class TradeSPOT(TradeOpen, TradeClose):
    pass
