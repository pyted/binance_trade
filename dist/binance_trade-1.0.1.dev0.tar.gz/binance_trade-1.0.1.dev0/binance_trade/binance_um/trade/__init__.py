from binance_trade.binance_um.trade.open import TradeOpen
from binance_trade.binance_um.trade.close import TradeClose


class TradeUM(TradeOpen, TradeClose):
    pass
